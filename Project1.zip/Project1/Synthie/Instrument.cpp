#include "stdafx.h"
#include "Instrument.h"


CInstrument::CInstrument()
{
}

CInstrument::CInstrument(double bpm)
{
	m_bpm = bpm;
}

CInstrument::~CInstrument()
{
}
